-- MySQL dump 10.13  Distrib 5.7.11, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: chilliapp
-- ------------------------------------------------------
-- Server version	5.7.11-0ubuntu6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admissions`
--

DROP TABLE IF EXISTS `admissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `adm_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admissions_user_id_index` (`user_id`),
  KEY `admissions_adm_no_index` (`adm_no`),
  KEY `admissions_from_user_index` (`from_user`),
  CONSTRAINT `admissions_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `admissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admissions`
--

LOCK TABLES `admissions` WRITE;
/*!40000 ALTER TABLE `admissions` DISABLE KEYS */;
INSERT INTO `admissions` VALUES (1,4,'323',1,'2017-07-26 09:13:03','2017-07-26 09:13:03'),(2,5,'34344',1,'2017-07-26 10:07:42','2017-07-26 10:07:42'),(3,6,'43543',1,'2017-07-26 10:08:24','2017-07-26 10:08:24'),(4,7,'de323',1,'2017-08-14 05:32:14','2017-08-14 05:32:14'),(5,8,'Ads33',1,'2017-08-14 05:32:14','2017-08-14 05:32:14'),(6,9,'44d3d',1,'2017-08-14 05:32:15','2017-08-14 05:32:15'),(7,10,'4dd32',1,'2017-08-14 08:13:36','2017-08-14 08:13:36'),(8,11,'Tr4342',1,'2017-08-14 08:14:13','2017-08-14 08:14:13'),(9,12,'43j642',1,'2017-08-14 08:15:02','2017-08-14 08:15:02'),(10,13,'jfa4g3',1,'2017-08-14 08:16:36','2017-08-14 08:16:36'),(11,14,'Jue323',1,'2017-08-14 08:18:48','2017-08-14 08:18:48'),(12,15,'KT494',1,'2017-08-14 08:19:35','2017-08-14 08:19:35'),(13,16,'43ha32',1,'2017-08-14 08:21:43','2017-08-14 08:21:43'),(14,17,'Jitd43',1,'2017-08-14 08:23:30','2017-08-14 08:23:30'),(15,18,'JtRere34',1,'2017-08-14 08:24:46','2017-08-14 08:24:46'),(16,19,'mn323',1,'2017-08-14 08:27:26','2017-08-14 08:27:26'),(17,20,'5fdaf',1,'2017-08-14 08:30:15','2017-08-14 08:30:15'),(18,21,'Tie3434',1,'2017-08-14 08:31:27','2017-08-14 08:31:27');
/*!40000 ALTER TABLE `admissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessments`
--

DROP TABLE IF EXISTS `assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assessments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `exam_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teacher_id` int(10) unsigned NOT NULL,
  `out_of` double DEFAULT NULL,
  `contribution` double NOT NULL,
  `status` int(10) unsigned NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assessments_exam_id_index` (`exam_id`),
  KEY `assessments_name_index` (`name`),
  KEY `assessments_teacher_id_index` (`teacher_id`),
  KEY `assessments_out_of_index` (`out_of`),
  KEY `assessments_contribution_index` (`contribution`),
  KEY `assessments_status_index` (`status`),
  KEY `assessments_from_user_index` (`from_user`),
  CONSTRAINT `assessments_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assessments_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessments`
--

LOCK TABLES `assessments` WRITE;
/*!40000 ALTER TABLE `assessments` DISABLE KEYS */;
/*!40000 ALTER TABLE `assessments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backups_name_index` (`name`),
  KEY `backups_location_index` (`location`),
  KEY `backups_from_user_index` (`from_user`),
  CONSTRAINT `backups_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `classes_name_index` (`name`),
  KEY `classes_year_index` (`year`),
  KEY `classes_from_user_index` (`from_user`),
  CONSTRAINT `classes_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` VALUES (4,'Form 1','2017',1,'2017-08-13 17:14:10','2017-08-13 17:14:10'),(5,'Form 2','2017',1,'2017-08-13 17:14:29','2017-08-13 17:14:29'),(6,'Form 3','2017',1,'2017-08-13 17:14:45','2017-08-13 17:14:45'),(7,'Form 4','2017',1,'2017-08-13 17:15:02','2017-08-13 17:15:02');
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes_report_exam`
--

DROP TABLE IF EXISTS `classes_report_exam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classes_report_exam` (
  `exam_id` int(10) unsigned NOT NULL,
  `classes_report_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `classes_report_exam_exam_id_index` (`exam_id`),
  KEY `classes_report_exam_classes_report_id_index` (`classes_report_id`),
  CONSTRAINT `classes_report_exam_classes_report_id_foreign` FOREIGN KEY (`classes_report_id`) REFERENCES `classes_reports` (`id`),
  CONSTRAINT `classes_report_exam_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes_report_exam`
--

LOCK TABLES `classes_report_exam` WRITE;
/*!40000 ALTER TABLE `classes_report_exam` DISABLE KEYS */;
/*!40000 ALTER TABLE `classes_report_exam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes_reports`
--

DROP TABLE IF EXISTS `classes_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classes_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `classes_reports_name_index` (`name`),
  KEY `classes_reports_from_user_index` (`from_user`),
  CONSTRAINT `classes_reports_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes_reports`
--

LOCK TABLES `classes_reports` WRITE;
/*!40000 ALTER TABLE `classes_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `classes_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_classes_report`
--

DROP TABLE IF EXISTS `exam_classes_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_classes_report` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classes_report_id` int(10) unsigned NOT NULL,
  `exam_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exam_classes_report_classes_report_id_index` (`classes_report_id`),
  KEY `exam_classes_report_exam_id_index` (`exam_id`),
  CONSTRAINT `exam_classes_report_classes_report_id_foreign` FOREIGN KEY (`classes_report_id`) REFERENCES `classes_reports` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_classes_report_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_classes_report`
--

LOCK TABLES `exam_classes_report` WRITE;
/*!40000 ALTER TABLE `exam_classes_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_classes_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_stream_report`
--

DROP TABLE IF EXISTS `exam_stream_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_stream_report` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stream_report_id` int(10) unsigned NOT NULL,
  `exam_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exam_stream_report_stream_report_id_index` (`stream_report_id`),
  KEY `exam_stream_report_exam_id_index` (`exam_id`),
  CONSTRAINT `exam_stream_report_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE NO ACTION,
  CONSTRAINT `exam_stream_report_stream_report_id_foreign` FOREIGN KEY (`stream_report_id`) REFERENCES `stream_reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_stream_report`
--

LOCK TABLES `exam_stream_report` WRITE;
/*!40000 ALTER TABLE `exam_stream_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_stream_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_streamreport`
--

DROP TABLE IF EXISTS `exam_streamreport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_streamreport` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `streamreport_id` int(10) unsigned NOT NULL,
  `exam_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exam_streamreport_streamreport_id_index` (`streamreport_id`),
  KEY `exam_streamreport_exam_id_index` (`exam_id`),
  CONSTRAINT `exam_streamreport_exam_id_foreign` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE NO ACTION,
  CONSTRAINT `exam_streamreport_streamreport_id_foreign` FOREIGN KEY (`streamreport_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_streamreport`
--

LOCK TABLES `exam_streamreport` WRITE;
/*!40000 ALTER TABLE `exam_streamreport` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_streamreport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  `stream_id` int(10) unsigned NOT NULL,
  `period` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(10) unsigned NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exams_name_index` (`name`),
  KEY `exams_subject_id_index` (`subject_id`),
  KEY `exams_stream_id_index` (`stream_id`),
  KEY `exams_period_index` (`period`),
  KEY `exams_year_index` (`year`),
  KEY `exams_status_index` (`status`),
  KEY `exams_from_user_index` (`from_user`),
  CONSTRAINT `exams_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grades`
--

DROP TABLE IF EXISTS `grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `assessment_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `marks` double unsigned NOT NULL,
  `status` int(10) unsigned NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `grades_assessment_id_index` (`assessment_id`),
  KEY `grades_student_id_index` (`student_id`),
  KEY `grades_marks_index` (`marks`),
  KEY `grades_status_index` (`status`),
  KEY `grades_from_user_index` (`from_user`),
  CONSTRAINT `grades_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `grades_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grades`
--

LOCK TABLES `grades` WRITE;
/*!40000 ALTER TABLE `grades` DISABLE KEYS */;
/*!40000 ALTER TABLE `grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_user`
--

DROP TABLE IF EXISTS `group_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `group_user_user_id_index` (`user_id`),
  KEY `group_user_group_id_index` (`group_id`),
  CONSTRAINT `group_user_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE NO ACTION,
  CONSTRAINT `group_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_user`
--

LOCK TABLES `group_user` WRITE;
/*!40000 ALTER TABLE `group_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `groups_name_index` (`name`),
  KEY `groups_from_user_index` (`from_user`),
  CONSTRAINT `groups_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `messages_name_index` (`name`),
  KEY `messages_from_user_index` (`from_user`),
  CONSTRAINT `messages_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2017_07_13_095257_create_classes_table',1),(4,'2017_07_13_095519_create_messages_table',1),(5,'2017_07_13_095554_create_roles_table',1),(6,'2017_07_13_095613_create_school_table',1),(7,'2017_07_13_095631_create_admissions_table',1),(8,'2017_07_13_095730_create_role_user_table',1),(9,'2017_07_13_115223_create_subjects_table',1),(10,'2017_07_13_211144_create_streams_table',1),(11,'2017_07_14_095348_create_exams_table',1),(12,'2017_07_18_092210_create_groups_table',1),(13,'2017_07_18_092317_create_group_user_table',1),(14,'2017_07_18_210621_create_stream_user_table',1),(15,'2017_07_24_145018_create_assessments_table',1),(16,'2017_07_24_202807_create_grades_table',1),(17,'2017_07_27_084219_create_streamreports_table',2),(18,'2017_07_27_090548_create_exam_streamreport_table',3),(19,'2017_07_27_114524_create_stream_reports_table',4),(20,'2017_07_27_114557_create_exam_stream_report_table',4),(21,'2017_08_02_173848_create_class_reports_table',5),(22,'2017_08_02_173931_create_exam_class_report_table',5),(23,'2017_08_03_124329_create_class_report_exam_table',6),(24,'2017_08_03_125820_create_class_report_exam_table',7),(25,'2017_08_03_133045_create_classes_report_table',8),(26,'2017_08_03_133048_create_exam_classes_report_table',8),(28,'2017_08_03_134012_create_classes_report_exam_table',9),(29,'2017_08_03_145350_create_classes_report_exam_table',10),(30,'2017_08_11_211738_create_subject_user_table',11),(31,'2017_08_12_192836_create_schools_table',12),(32,'2017_08_14_142146_create_backups_table',13);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_user_user_id_index` (`user_id`),
  KEY `role_user_role_id_index` (`role_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE NO ACTION,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,1,1,'2017-07-26 09:13:02','2017-07-26 09:13:02'),(2,2,2,'2017-07-26 09:13:02','2017-07-26 09:13:02'),(4,4,4,'2017-07-26 09:13:03','2017-07-26 09:13:03'),(5,5,4,'2017-07-26 10:07:42','2017-07-26 10:07:42'),(6,6,4,'2017-07-26 10:08:24','2017-07-26 10:08:24'),(7,7,4,'2017-08-14 05:32:14','2017-08-14 05:32:14'),(8,8,4,'2017-08-14 05:32:14','2017-08-14 05:32:14'),(9,9,4,'2017-08-14 05:32:15','2017-08-14 05:32:15'),(10,10,4,'2017-08-14 08:13:36','2017-08-14 08:13:36'),(11,11,4,'2017-08-14 08:14:13','2017-08-14 08:14:13'),(12,12,4,'2017-08-14 08:15:02','2017-08-14 08:15:02'),(13,13,4,'2017-08-14 08:16:35','2017-08-14 08:16:35'),(14,14,4,'2017-08-14 08:18:48','2017-08-14 08:18:48'),(15,15,4,'2017-08-14 08:19:35','2017-08-14 08:19:35'),(16,16,4,'2017-08-14 08:21:42','2017-08-14 08:21:42'),(17,17,4,'2017-08-14 08:23:30','2017-08-14 08:23:30'),(18,18,4,'2017-08-14 08:24:46','2017-08-14 08:24:46'),(19,19,4,'2017-08-14 08:27:26','2017-08-14 08:27:26'),(20,20,4,'2017-08-14 08:30:15','2017-08-14 08:30:15'),(21,21,4,'2017-08-14 08:31:27','2017-08-14 08:31:27'),(22,22,3,'2017-08-14 08:38:22','2017-08-14 08:38:22'),(23,23,3,'2017-08-14 08:39:12','2017-08-14 08:39:12'),(24,24,3,'2017-08-14 08:39:35','2017-08-14 08:39:35'),(25,25,3,'2017-08-14 08:40:05','2017-08-14 08:40:05'),(26,26,3,'2017-08-14 08:40:34','2017-08-14 08:40:34'),(27,27,3,'2017-08-14 08:41:18','2017-08-14 08:41:18'),(28,28,3,'2017-08-14 08:42:07','2017-08-14 08:42:07'),(29,29,3,'2017-08-14 08:42:28','2017-08-14 08:42:28'),(30,30,3,'2017-08-14 09:02:42','2017-08-14 09:02:42'),(31,31,3,'2017-08-14 09:03:01','2017-08-14 09:03:01'),(32,32,3,'2017-08-14 09:03:23','2017-08-14 09:03:23'),(33,33,3,'2017-08-14 09:03:53','2017-08-14 09:03:53'),(34,34,3,'2017-08-14 09:04:21','2017-08-14 09:04:21'),(35,35,3,'2017-08-14 09:05:03','2017-08-14 09:05:03'),(36,36,3,'2017-08-14 09:05:45','2017-08-14 09:05:45'),(37,37,3,'2017-08-14 09:06:21','2017-08-14 09:06:21'),(38,38,3,'2017-08-14 09:06:45','2017-08-14 09:06:45'),(39,39,3,'2017-08-14 09:07:14','2017-08-14 09:07:14'),(40,40,3,'2017-08-14 09:07:30','2017-08-14 09:07:30'),(41,41,3,'2017-08-14 09:07:51','2017-08-14 09:07:51'),(42,42,3,'2017-08-14 09:08:34','2017-08-14 09:08:34'),(43,43,3,'2017-08-14 09:08:56','2017-08-14 09:08:56'),(44,44,3,'2017-08-14 09:09:19','2017-08-14 09:09:19'),(45,45,3,'2017-08-14 09:09:39','2017-08-14 09:09:39'),(46,46,3,'2017-08-14 09:09:56','2017-08-14 09:09:56'),(47,47,3,'2017-08-14 09:10:51','2017-08-14 09:10:51'),(48,48,3,'2017-08-14 09:11:12','2017-08-14 09:11:12'),(49,49,3,'2017-08-14 09:11:27','2017-08-14 09:11:27'),(50,50,3,'2017-08-14 09:11:53','2017-08-14 09:11:53'),(51,51,3,'2017-08-14 09:12:16','2017-08-14 09:12:16'),(52,52,3,'2017-08-14 09:12:38','2017-08-14 09:12:38'),(53,53,3,'2017-08-14 09:13:00','2017-08-14 09:13:00'),(54,54,3,'2017-08-14 09:13:38','2017-08-14 09:13:38'),(55,55,3,'2017-08-14 09:26:36','2017-08-14 09:26:36'),(56,56,3,'2017-08-14 09:27:25','2017-08-14 09:27:25');
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_name_index` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'superadmin','2017-07-26 09:13:01','2017-07-26 09:13:01'),(2,'admin','2017-07-26 09:13:01','2017-07-26 09:13:01'),(3,'teacher','2017-07-26 09:13:02','2017-07-26 09:13:02'),(4,'student','2017-07-26 09:13:02','2017-07-26 09:13:02');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schools`
--

DROP TABLE IF EXISTS `schools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schools` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `school_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schools_name_index` (`name`),
  KEY `schools_address_index` (`address`),
  KEY `schools_phone_index` (`phone`),
  KEY `schools_school_type_index` (`school_type`),
  KEY `schools_from_user_index` (`from_user`),
  CONSTRAINT `schools_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schools`
--

LOCK TABLES `schools` WRITE;
/*!40000 ALTER TABLE `schools` DISABLE KEYS */;
INSERT INTO `schools` VALUES (1,'ChilliApp School','P.O Box 1222 - 00300 Nairobi, Kenya','+254 703 443 343','kenyan_secondary',1,'2017-08-12 17:16:48','2017-08-14 05:10:08');
/*!40000 ALTER TABLE `schools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_reports`
--

DROP TABLE IF EXISTS `stream_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stream_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stream_reports_name_index` (`name`),
  KEY `stream_reports_from_user_index` (`from_user`),
  CONSTRAINT `stream_reports_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_reports`
--

LOCK TABLES `stream_reports` WRITE;
/*!40000 ALTER TABLE `stream_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `stream_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_user`
--

DROP TABLE IF EXISTS `stream_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stream_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `stream_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stream_user_user_id_index` (`user_id`),
  KEY `stream_user_stream_id_index` (`stream_id`),
  CONSTRAINT `stream_user_stream_id_foreign` FOREIGN KEY (`stream_id`) REFERENCES `streams` (`id`) ON DELETE NO ACTION,
  CONSTRAINT `stream_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_user`
--

LOCK TABLES `stream_user` WRITE;
/*!40000 ALTER TABLE `stream_user` DISABLE KEYS */;
INSERT INTO `stream_user` VALUES (1,4,10,'2017-08-14 05:14:42','2017-08-14 05:14:42'),(2,5,10,'2017-08-14 05:28:55','2017-08-14 05:28:55'),(3,6,10,'2017-08-14 05:29:11','2017-08-14 05:29:11'),(4,7,11,'2017-08-14 05:37:41','2017-08-14 05:37:41'),(5,8,11,'2017-08-14 05:37:42','2017-08-14 05:37:42'),(6,9,11,'2017-08-14 05:37:42','2017-08-14 05:37:42'),(7,10,12,'2017-08-14 08:15:26','2017-08-14 08:15:26'),(8,11,12,'2017-08-14 08:15:26','2017-08-14 08:15:26'),(9,12,12,'2017-08-14 08:15:26','2017-08-14 08:15:26'),(10,13,13,'2017-08-14 08:20:45','2017-08-14 08:20:45'),(11,14,13,'2017-08-14 08:20:45','2017-08-14 08:20:45'),(12,15,13,'2017-08-14 08:20:45','2017-08-14 08:20:45'),(13,16,14,'2017-08-14 08:25:08','2017-08-14 08:25:08'),(14,17,14,'2017-08-14 08:25:08','2017-08-14 08:25:08'),(15,18,14,'2017-08-14 08:25:08','2017-08-14 08:25:08'),(16,19,15,'2017-08-14 08:34:00','2017-08-14 08:34:00'),(17,20,15,'2017-08-14 08:34:00','2017-08-14 08:34:00'),(18,21,15,'2017-08-14 08:34:00','2017-08-14 08:34:00');
/*!40000 ALTER TABLE `stream_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streamreports`
--

DROP TABLE IF EXISTS `streamreports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streamreports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `streamreports_name_index` (`name`),
  KEY `streamreports_from_user_index` (`from_user`),
  CONSTRAINT `streamreports_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streamreports`
--

LOCK TABLES `streamreports` WRITE;
/*!40000 ALTER TABLE `streamreports` DISABLE KEYS */;
INSERT INTO `streamreports` VALUES (1,'Opening term mid',1,'2017-07-27 08:38:52','2017-07-27 08:38:52'),(2,'Opening term mid',1,'2017-07-27 08:39:08','2017-07-27 08:39:08'),(3,'Opening term mid',1,'2017-07-27 08:42:00','2017-07-27 08:42:00');
/*!40000 ALTER TABLE `streamreports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams`
--

DROP TABLE IF EXISTS `streams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abbr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class_id` int(11) NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `streams_name_index` (`name`),
  KEY `streams_abbr_index` (`abbr`),
  KEY `streams_class_id_index` (`class_id`),
  KEY `streams_from_user_index` (`from_user`),
  CONSTRAINT `streams_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams`
--

LOCK TABLES `streams` WRITE;
/*!40000 ALTER TABLE `streams` DISABLE KEYS */;
INSERT INTO `streams` VALUES (10,'Form 1S','1S',4,1,'2017-08-13 17:15:29','2017-08-13 17:15:29'),(11,'Form 1P','1P',4,1,'2017-08-13 17:16:10','2017-08-13 17:16:10'),(12,'Form 1D','1D',4,1,'2017-08-13 17:16:34','2017-08-13 17:16:34'),(13,'Form 1G','1G',4,1,'2017-08-13 17:17:04','2017-08-13 17:17:04'),(14,'Form 1E','1E',4,1,'2017-08-13 17:17:40','2017-08-13 17:19:57'),(15,'Form 1T','1T',4,1,'2017-08-13 17:22:18','2017-08-13 17:22:18');
/*!40000 ALTER TABLE `streams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_user`
--

DROP TABLE IF EXISTS `subject_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject_user_user_id_index` (`user_id`),
  KEY `subject_user_subject_id_index` (`subject_id`),
  CONSTRAINT `subject_user_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE NO ACTION,
  CONSTRAINT `subject_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_user`
--

LOCK TABLES `subject_user` WRITE;
/*!40000 ALTER TABLE `subject_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `subject_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abbr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subjects_name_index` (`name`),
  KEY `subjects_abbr_index` (`abbr`),
  KEY `subjects_code_index` (`code`),
  KEY `subjects_from_user_index` (`from_user`),
  CONSTRAINT `subjects_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (6,'English','Eng','Eng',1,'2017-08-13 18:53:22','2017-08-13 18:53:22'),(7,'Mathematics','Maths','Maths',1,'2017-08-13 18:54:14','2017-08-13 18:54:14'),(8,'Kiswahili','Kiswa','Kiswa',1,'2017-08-13 18:54:44','2017-08-13 18:54:44'),(9,'Physics','Phy','Phy',1,'2017-08-13 18:55:15','2017-08-13 18:55:15'),(10,'Chemistry','Chem','Chem',1,'2017-08-13 18:55:36','2017-08-13 18:55:36'),(11,'Biology','Bio','Bio',1,'2017-08-13 18:56:09','2017-08-13 18:56:09'),(12,'Geography','Geo','Geo',1,'2017-08-13 18:56:30','2017-08-13 18:56:30'),(13,'History','His','His',1,'2017-08-13 18:56:54','2017-08-13 18:56:54'),(14,'Christian Religious Education','C.R.E','C.R.E',1,'2017-08-13 18:57:22','2017-08-13 18:57:22'),(15,'Agriculture','Agri','Agri',1,'2017-08-13 18:58:35','2017-08-13 18:58:35'),(16,'Business Studies','B/st','B/st',1,'2017-08-13 18:59:03','2017-08-13 18:59:03'),(17,'Islamic Religious Education','I.R.E','I.R.E',1,'2017-08-13 18:59:57','2017-08-13 18:59:57'),(18,'German','Ger','Ger',1,'2017-08-13 19:00:29','2017-08-13 19:00:29'),(19,'Home Science','H/sc','H/sc',1,'2017-08-13 19:01:02','2017-08-13 19:01:02'),(20,'French','Fre','Fre',1,'2017-08-13 19:01:31','2017-08-13 19:01:31'),(21,'Computer Studies','C/s','C/s',1,'2017-08-13 19:02:11','2017-08-13 19:02:11');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user` int(10) unsigned NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_name_index` (`name`),
  KEY `users_year_index` (`year`),
  KEY `users_phone_index` (`phone`),
  KEY `users_from_user_index` (`from_user`),
  CONSTRAINT `users_from_user_foreign` FOREIGN KEY (`from_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'John Doe','2017','0703436696','$2y$10$qMtNVojQRgF4UtgKgZguA.SI.uhsuk6ynQKJtRZhBAAgvwcTU1skq',1,'Xu0YoxccEAxgu5TahpBy1AWoYn09zWUZm0lO8UEga5PRjxjUtGWJoMSZQhDl','2017-07-26 09:13:02','2017-07-26 09:13:02'),(2,'Theresa Admin','2017','0703436697','$2y$10$VgREhHMHbuTJ1Ba075JlOOwvZ37vLkoQmcEiGRmiffSut10RoN2Tq',1,NULL,'2017-07-26 09:13:02','2017-07-26 09:13:02'),(4,'Jane Student','2017','0703436699','$2y$10$5cITxnpYgrldeajsd1lEAe4QkJtztGzZYUXxee2JpVW3vBHl2lcvy',1,NULL,'2017-07-26 09:13:03','2017-07-26 09:13:03'),(5,'Tom Kenneth','2017','0454545455','$2y$10$5S0zIIt.inTZvZQ4cu5lHOVeCT/4qJ8wA8LiHUxppcdQRKPeUv9Xm',1,NULL,'2017-07-26 10:07:42','2017-07-26 10:07:42'),(6,'Titus Simon','2017','4534343434','$2y$10$yvJH/AtBNhrv7tZjfLdbUOIDORFBllpnBw33n0X6oBZeNC2JvqK2a',1,NULL,'2017-07-26 10:08:24','2017-07-26 10:08:24'),(7,'Kennedy Kimbo','2017','2323124323','$2y$10$3p4Bscg49Xb5SXcE2UQtGu7Z4Zbjig1azSb8CDtDKvwImTsUQ0Yn2',1,NULL,'2017-08-14 05:32:13','2017-08-14 05:32:13'),(8,'Susan Lenda','2017','5849348384','$2y$10$XASrFV4H/y7uHXfz4pTJxO6sjoUs.BZ2CUPdhTBEs8vy96ArfIrz2',1,NULL,'2017-08-14 05:32:14','2017-08-14 05:32:14'),(9,'Cyrus Kiptoo','2017','1234234532','$2y$10$ckqUhxfXpMbE58vVhKYzAeNu1aG2mA4jBNZS21.o/efcfRs3BxY7q',1,NULL,'2017-08-14 05:32:15','2017-08-14 05:32:15'),(10,'Joy Tress','2017','3843434325','$2y$10$onrtfFPZ5.YUwpuKZgheY.aBDR/q0FD3ZkJxoKJ.4OU3CJGP1jy3W',1,NULL,'2017-08-14 08:13:35','2017-08-14 08:13:35'),(11,'Tracy Paul','2017','5849523234','$2y$10$H8BF8vyzGFmgOYyHfm2kQuPXFMA1H5y29LLUy7InvNDZ5h.fovu26',1,NULL,'2017-08-14 08:14:13','2017-08-14 08:14:13'),(12,'Paul John','2017','43234566645','$2y$10$tv.vmcWe4G2Eu/siPZEVJ.eKIoYPbcmoDNv3KWbL/KjJWUkesK01S',1,NULL,'2017-08-14 08:15:02','2017-08-14 08:15:02'),(13,'Jane Tracy','2017','9584392345','$2y$10$ixryrHY9QFYE2iUdrApzLe8Ws.d/wTb43/jNVVSqgldWPKUTPAny2',1,NULL,'2017-08-14 08:16:35','2017-08-14 08:16:35'),(14,'Ahmed Nasir','2017','4344343564','$2y$10$mfJYLftWFEQ5RaaYjbOeFut5TZ94RAPqCpVI2OPie8TcAIR/vTNJu',1,NULL,'2017-08-14 08:18:47','2017-08-14 08:18:47'),(15,'Kennedy Jeffry','2017','9584344323','$2y$10$vxT48lMMTpGxtI1wExYeHOxaNCFACuPp4G.O87BsIujOmk3HIJRSm',1,NULL,'2017-08-14 08:19:35','2017-08-14 08:19:35'),(16,'Joseph Kiptoo','2017','5854534256','$2y$10$YXqfzDx5slxGpBQ0XYoGRu.BJkbs2PKE7W3.8kHEtuE4Wn9p1OV0q',1,NULL,'2017-08-14 08:21:42','2017-08-14 08:21:42'),(17,'Jimmy Trevor','2017','4354234314','$2y$10$iTnpmHVyzagSt6RIBYpQD.N6p/ilHGxABuRQ1JACX486/Ah5X0GSq',1,NULL,'2017-08-14 08:23:30','2017-08-14 08:23:30'),(18,'Jeremy Gerse','2017','9484939404','$2y$10$jnCkUI3cHcQuVpVfZWlJPe7C/22vQ/qTbyuaWqBLTTEblK3e812ZO',1,NULL,'2017-08-14 08:24:46','2017-08-14 08:24:46'),(19,'Pauline Kerry','2017','4834323456','$2y$10$uoQ0CZaHXeVrNkMKayytL.7bkf3OH/2gs4L4rrYKJr8y4f5bfbX1a',1,NULL,'2017-08-14 08:27:26','2017-08-14 08:27:26'),(20,'Rosemary Kereni','2017','8765412333','$2y$10$5IK9MGT9mSQMZN.jB3TnQOmGcKV0dWJ.GeUYMQex0705zyj64oiGq',1,NULL,'2017-08-14 08:30:15','2017-08-14 08:30:15'),(21,'Patricia Brasi','2017','3454534546','$2y$10$jkgu597cjgHa1poizjHwnO8r4JyKJNyMvimdrHGxgJFdoQyGUpy5y',1,NULL,'2017-08-14 08:31:27','2017-08-14 08:31:54'),(22,'Mrs. Thita','2017','8493232123','$2y$10$GPLiNY0ZGWioz61HnPMRGOriRMZZw5fabd0cz1/KvW7mMbsWxyxxG',1,NULL,'2017-08-14 08:38:22','2017-08-14 08:38:22'),(23,'Mrs. Mutua','2017','8593423432','$2y$10$WLsSDcCj/CfXWoFpINOFq.Ix09m99ecWu.6Zd50NQEeSVNGRPXP5y',1,NULL,'2017-08-14 08:39:12','2017-08-14 08:39:12'),(24,'Mr. Omondi','2017','9605654234','$2y$10$QdV787itoD1xWpcOBMFgZePcsIrcyGum5OEfhKC1YmbnpJWCyt2jO',1,NULL,'2017-08-14 08:39:35','2017-08-14 08:39:35'),(25,'Mr. Mwangi C.','2017','9485429343','$2y$10$mpIC4/SyHrc6WlM.G7XqmOn0ygHaamKMVZzXJVUuxlLQS.W/goawy',1,NULL,'2017-08-14 08:40:05','2017-08-14 08:40:05'),(26,'Mr. Simon','2017','9485843923','$2y$10$GzhMKgNVUnmWLEX.66E1WelMMDCH5Bt8bLLcw3HP2gSn807KA1Ziq',1,NULL,'2017-08-14 08:40:34','2017-08-14 08:40:34'),(27,'Mrs. Kiptoo','2017','5454367843','$2y$10$jNmX6kTJpRTkI1KuI26FUuJ4qlwXI8kebkpWqY9iEIQyx/n7LPKzW',1,NULL,'2017-08-14 08:41:18','2017-08-14 08:41:18'),(28,'Mrs. Gichoya','2017','9574543245','$2y$10$Af6UwzcLncTzSLDYNL275O9xlVcVu9voub7Gj4Sv9KWa046G5.y9m',1,NULL,'2017-08-14 08:42:07','2017-08-14 08:42:07'),(29,'Mr. Munene','2017','8695849583','$2y$10$f1cyKkmYAHqxuzK8Y50XrODPQKmZo2v./JbcgcwqNiHONlV2SY3fS',1,NULL,'2017-08-14 08:42:28','2017-08-14 08:42:28'),(30,'Mr. Mureithi','2017','3848484323','$2y$10$mqTtpoO2KpwTtt8LTWH7xeXoVWVq8ks1o7dpd36li0rfouwRVEl5q',1,NULL,'2017-08-14 09:02:42','2017-08-14 09:02:42'),(31,'Mr. Francis','2017','84758473884','$2y$10$deK1hUg4vlyTZ41UuoEg9OdfsHIt2yyh2duykE8bh1uy381HELODe',1,NULL,'2017-08-14 09:03:01','2017-08-14 09:03:01'),(32,'Mr. Kioko','2017','4857483748','$2y$10$EFybGt1GiwDzJNTa7/3xL.q6nLgJWUCaSJQaRFdiuDvh/k5e/SZl6',1,NULL,'2017-08-14 09:03:23','2017-08-14 09:03:23'),(33,'Mr. Gathu','2017','3838283928','$2y$10$Gkmed4LjZsQwTl9DiBWc4ObWKbUH1m3xSPYvNwudbhn0IBui1Tmiu',1,NULL,'2017-08-14 09:03:53','2017-08-14 09:03:53'),(34,'Mrs. Owino','2017','4756323323','$2y$10$Kiyavb2NuLaRThzRpqsGKuDUtDxWsvmncFOb3GBAW5lzxAzWmAugG',1,NULL,'2017-08-14 09:04:21','2017-08-14 09:04:21'),(35,'Mr. Karuri','2017','3384930494','$2y$10$k5BlnWIEJn0dyPe.9AOca..Itz2WTqtpJdh0KQcsExRGOmDPDH4Dy',1,NULL,'2017-08-14 09:05:03','2017-08-14 09:05:03'),(36,'Mrs. Karanja','2017','9605967548','$2y$10$w.RhEJ93jPQ9FfWDOPMTk.kI2wHbIUdozW8PY2LRh2IzfLHwTDXSG',1,NULL,'2017-08-14 09:05:45','2017-08-14 09:05:45'),(37,'Mrs. Bett','2017','0696858748','$2y$10$r68WWy/jy8Je8qrCfxq2g.BbEcA12XxrMnSgE1mV7.TgqY/FxegOa',1,NULL,'2017-08-14 09:06:21','2017-08-14 09:06:21'),(38,'Mrs. Ombajo','2017','8574857485','$2y$10$TSjWmJ3M9GQ93SfSrs6E3uxVCWJ.E0nlyKD.PqltSGl/0DLVj6qG2',1,NULL,'2017-08-14 09:06:45','2017-08-14 09:06:45'),(39,'Mrs. Mwendwa','2017','8695758473','$2y$10$cA9E3z33uPDkqeH7B2beO.TAaoDIe35uxv/5qYoo9bqtMTfGz6RbW',1,NULL,'2017-08-14 09:07:14','2017-08-14 09:07:14'),(40,'Mrs. Muindi','2017','9685948594','$2y$10$hz4.ecrOZREFH/GpGOHDCuPoDp2/DRHDRw01fymcUVpMmcSzr.A6O',1,NULL,'2017-08-14 09:07:30','2017-08-14 09:07:30'),(41,'Mr. Masolia','2017','9706958473','$2y$10$1I.J9njErchUH3nNgjCSfuYGD/3fCGRdkaXQmp16ANN8iybyXv0Oe',1,NULL,'2017-08-14 09:07:51','2017-08-14 09:07:51'),(42,'Mr. K Mwangi','2017','8485554348','$2y$10$0Eo/xffoMBp9dRY43vlGN.19hm1y5h/5UJ5BM5f/lDJBEjV1mumTW',1,NULL,'2017-08-14 09:08:34','2017-08-14 09:08:34'),(43,'Mrs. Chelule','2017','8495849388','$2y$10$6KXBbiCWa5Hl0BEEwHwwceswwiBnEH507PlvPq4RHc745SOMh7Fu.',1,NULL,'2017-08-14 09:08:56','2017-08-14 09:08:56'),(44,'Mrs. Mirie','2017','4433453434','$2y$10$qZxl/ZXH9XswYz.5mpOWduuAMliLWi9/oxDFnkGiO6Byqj07jtbpe',1,NULL,'2017-08-14 09:09:19','2017-08-14 09:09:19'),(45,'Mrs. Barsito','2017','4388854545','$2y$10$18ArOUyNBArbBeuG2GvmrefP.TTkrua5P6Uk5Ywc3o.pq8rbjzqKC',1,NULL,'2017-08-14 09:09:38','2017-08-14 09:09:38'),(46,'Mr. Mwangi K.','2017','9584938473','$2y$10$L4Z7uz5tmpgj6aCHwMzMEOM7vdvksOVPCitEsRpXrBeKH2Q.afA1i',1,NULL,'2017-08-14 09:09:56','2017-08-14 09:09:56'),(47,'Mr. Ng\'eno','2017','5454343532','$2y$10$Ew7/eg1bGCATBC0BTe3jN.EqvhHYIbhvO4UqJhRgCGIstlPXQ8T5K',1,NULL,'2017-08-14 09:10:51','2017-08-14 09:10:51'),(48,'Ms. Sakwa','2017','4433443322','$2y$10$8TfwKQ2cBvp7ce44zMSNy.nUZ/Iw5dpHNzVdA5clHFp0pJRHl9.w2',1,NULL,'2017-08-14 09:11:11','2017-08-14 09:11:11'),(49,'Mr. Mwangi J.','2017','4434356789','$2y$10$oBaXK9bSV4KDR/usT1eCG.BG3HGs3lwyGrNnTWuSBB3DdaErpX8i2',1,NULL,'2017-08-14 09:11:27','2017-08-14 09:11:27'),(50,'Mrs. Obayo','2017','8596849583','$2y$10$/lDT/KoqsSS.vm1kLGG/5Ofar3px/HVCNO6m0qfX9bXjZSNXEb6Bm',1,NULL,'2017-08-14 09:11:53','2017-08-14 09:11:53'),(51,'Ms. John','2017','4355543334','$2y$10$.1KqMeCl1ENkFTAf2jlaP.fTvb3W4qcnyA.H3wGRsFCOX7bwSdIMi',1,NULL,'2017-08-14 09:12:16','2017-08-14 09:12:16'),(52,'Mr. Mwangi D.','2017','0495859485','$2y$10$m/Zuube7xvcNLOmy.NqO0uYIBLcJIqG9MCYmGI4LUL2espIjEZtUa',1,NULL,'2017-08-14 09:12:38','2017-08-14 09:12:38'),(53,'Mr. Maridich','2017','9485748594','$2y$10$YuEBlADsTEI/Jvqb8g2HvufhhvtVoCejLCb/n9jQO4l4MjVl4p/Je',1,NULL,'2017-08-14 09:13:00','2017-08-14 09:13:00'),(54,'Ms. John','2017','5455544444','$2y$10$YnScvzAP1GNAz3A3Mu9Yyelpn.VopmfmxQFosc1AOBRgADj9sOyIq',1,NULL,'2017-08-14 09:13:38','2017-08-14 09:13:38'),(55,'Mrs. Maragia','2017','8576857485','$2y$10$aHSSK3dcTiSNyUgdXZlGFO51SL39VU4SlMEZdk9qSCVy6iMUQsP3q',1,NULL,'2017-08-14 09:26:36','2017-08-14 09:26:36'),(56,'Mrs. Ndegwa','2017','8594859483','$2y$10$HvrM2U.I5n9IKrLSkbpEgupNa8IEQixagz1KIeEd0fZXJSH2170D.',1,NULL,'2017-08-14 09:27:25','2017-08-14 09:27:25');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-14 18:11:12
